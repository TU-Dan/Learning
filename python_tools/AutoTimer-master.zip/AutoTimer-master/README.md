Tracking the desktop applications in real time and time spent on each application.

Check out this for more https://youtu.be/ZBLYcvPl1MA 

Dependencies:

- selenium


Windows Depencies

- pywin32
- python-dateutil
- uiautomation 

